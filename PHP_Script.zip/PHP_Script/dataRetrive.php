<?php
$host_name ="localhost";
$host_user ="id14435746_rztutul";
$host_pass ="DKW(im59+oIY0q&4";
$host_db ="id14435746_mydb";
$conncetion = mysqli_connect($host_name,$host_user,$host_pass,$host_db);
$result = array();
$result['data'] =array();

$sql = "SELECT * FROM usertbl";
$response = mysqli_query($conncetion,$sql);

while ($rows = mysqli_fetch_array($response)  ) {
	$index['u_id'] = $rows['0'];
	$index['email'] = $rows['1'];
	$index['pass'] = $rows['2'];

	array_push($result['data'], $index);

}

$result['success'] ="1";
echo json_encode($result);
mysqli_close($conncetion)

?>