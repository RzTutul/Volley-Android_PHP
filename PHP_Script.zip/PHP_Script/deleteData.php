<?php
$host_name ="localhost";
$host_user ="id14435746_rztutul";
$host_pass ="DKW(im59+oIY0q&4";
$host_db ="id14435746_mydb";
$conncetion = mysqli_connect($host_name,$host_user,$host_pass,$host_db);
$id = $_POST["u_id"];
$query = "DELETE FROM usertbl WHERE u_id = '$id' ";
$result  = mysqli_query($conncetion,$query);
if ($result) {
	echo "data deleted";
}
else
{
	echo "deted fail";
}

?>