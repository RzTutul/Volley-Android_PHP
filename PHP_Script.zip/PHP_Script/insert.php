<?php 
$host_name ="localhost";
$host_user ="id14435746_rztutul";
$host_pass ="DKW(im59+oIY0q&4";
$host_db ="id14435746_mydb";
$conncetion = mysqli_connect($host_name,$host_user,$host_pass,$host_db);
$insert_email = $_POST["email"];
$insert_pass = $_POST["pass"];
$query = "INSERT INTO usertbl(email,pass) VALUES ('$insert_email','$insert_pass')";
$result = mysqli_query($conncetion,$query);
if ($result) {
echo "data insert Successfully";
}
else
{
    echo 'fails';
}
 

  

?>