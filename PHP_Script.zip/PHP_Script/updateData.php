<?php
$host_name ="localhost";
$host_user ="id14435746_rztutul";
$host_pass ="DKW(im59+oIY0q&4";
$host_db ="id14435746_mydb";
$conncetion = mysqli_connect($host_name,$host_user,$host_pass,$host_db);
$id = $_POST['id'];
$email = $_POST["email"];
$pass = $_POST["pass"];
$sql = "UPDATE `usertbl` SET `email`='$email',`pass`='$pass' WHERE u_id ='$id' ";
$result = mysqli_query($conncetion,$sql);
if($result){
	echo "Updated";
}
else
{
	echo "updated fail";
}
?>