<?php
$host_name ="localhost";
$host_user ="id14435746_rztutul";
$host_pass ="DKW(im59+oIY0q&4";
$host_db ="id14435746_mydb";
$conncetion = mysqli_connect($host_name,$host_user,$host_pass,$host_db);
if(isset($_POST))
{
$target_dir = "Images/";
$image = $_POST['images'];
$image_store = rand()."_".time().".jpeg";
$target_dir=$target_dir."/".$image_store;
file_put_contents($target_dir, base64_decode($image));
$query = "INSERT INTO imageData(images) VALUES('$image_store')";
$response = mysqli_query($conncetion,$query);
if ($response) {
echo "Image Upload";
}
else
{
	echo "upload fail";
}
}
?>