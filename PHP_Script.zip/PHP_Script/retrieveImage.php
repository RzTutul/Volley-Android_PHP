<?php
$host_name ="localhost";
$host_user ="id14435746_rztutul";
$host_pass ="DKW(im59+oIY0q&4";
$host_db ="id14435746_mydb";
$conncetion = mysqli_connect($host_name,$host_user,$host_pass,$host_db);
$result = array();
$result['data'] =array();

$sql = "SELECT * FROM imageData";
$response = mysqli_query($conncetion,$sql);

while ($rows = mysqli_fetch_array($response)  ) {
	$index['id'] = $rows['0'];
	$index['images'] = $rows['1'];


	array_push($result['data'], $index);

}

$result['success'] ="1";
echo json_encode($result);
mysqli_close($conncetion)

?>