<?php 
$host_name ="localhost";
$host_user ="id14435746_rztutul";
$host_pass ="DKW(im59+oIY0q&4";
$host_db ="id14435746_mydb";
$conncetion = mysqli_connect($host_name,$host_user,$host_pass,$host_db);
$email = $_POST["email"];
$pass = $_POST["pass"];
$query = "SELECT * FROM usertbl WHERE email = '$email' and  pass = '$pass' ";
$result = mysqli_query($conncetion,$query);
if ($result->num_rows > 0) {
echo "login Successfully";
}
else
{
echo "User not Found";
}
 ?>